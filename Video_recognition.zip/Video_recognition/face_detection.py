# import tools
from typing import Counter
import cv2
import os
import numpy as np

# import face data
folder_name = 'C:/Users/User/Desktop/file rama/Project/Video_recognition/face data'
name_folder = 'C:/Users/User/Desktop/file rama/Project/Video_recognition/recognizor'

# import cascade file
face_cascade_file = 'C:/Users/User/Desktop/file rama/Project/Video_recognition/cascade/face-detect.xml'
face_cascade = cv2.CascadeClassifier(face_cascade_file)

# camera operation
total_images = 5
counter = 1
ids = 1

# camera operation
cam = cv2.VideoCapture(0)
while True:
   _, frame = cam.read()
   frame_gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

   faces = face_cascade.detectMultiScale(frame_gray, 1.3, 3)

  # membuat 
   for x, y, w, h in faces:
     cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 225, 0), 3)

    # membuat tombol capture
     if cv2.waitKey(1) & 0xff == ord('c'):
       roi_face = frame[y:y+h, x:x+w]
       cv2.imwrite(f'{folder_name}/people.{ids}.{counter}.jpg', roi_face,)

       counter += 1
       if counter > total_images :
         print(f'{total_images} image capture')
        
# show camera detection
   cv2.imshow('FACE DETECTION', frame)
   print(faces)

   if cv2.waitKey(1)& 0xff == ord('x'):
      break      

cam.release()
cv2.destroyAllWindows()  

# create object recognizer
recognizer = cv2.face.LBPHFaceRecognizer_create()
path_images = os.listdir(folder_name)
image_arrays = []
image_ids = []

for path_image in path_images:
  split_path = path_image.split('.')
  image_id = int (split_path[1])

  img_path = os.path.join(folder_name, path_image)
  image = cv2.imread(img_path)
  image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

  image_array = np.array(image)
  image_arrays.append(image_array)
  image_ids.append(image_id)

recognizer.train(image_arrays, np.array(image_ids))
recognizer.save('recognizor/recognizor.yml')
print('berhasil')

